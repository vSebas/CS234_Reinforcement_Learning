cd code
python -m zipfile -c ../assignment2.zip network_utils.py policy.py policy_gradient.py baseline_network.py ppo.py
cd ../
